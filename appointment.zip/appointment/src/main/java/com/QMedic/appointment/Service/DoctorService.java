package com.QMedic.appointment.Service;

import com.QMedic.appointment.Entity.Doctor;
import com.QMedic.appointment.Repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {

    // Inject the repository dependency
    @Autowired
    private DoctorRepository doctorRepository;

    // Method to save a doctor
    public Doctor saveDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    // Method to get a doctor by id
    public Doctor getDoctorById(Long id) {
        return doctorRepository.findById(id).orElse(null);
    }

    // Method to get all doctors
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    // Method to delete a doctor by id
    public void deleteDoctorById(Long id) {
        doctorRepository.deleteById(id);
    }

}
