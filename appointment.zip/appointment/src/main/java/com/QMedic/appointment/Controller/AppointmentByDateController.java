package com.QMedic.appointment.Controller;

import com.QMedic.appointment.Entity.AppointmentByDate;
import com.QMedic.appointment.Service.AppointmentByDateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/appointmentsByDate")
public class AppointmentByDateController {

    private final AppointmentByDateService appointmentByDateService;

    @Autowired
    public AppointmentByDateController(AppointmentByDateService appointmentByDateService) {
        this.appointmentByDateService = appointmentByDateService;
    }

    // Get all appointments
    @GetMapping
    public ResponseEntity<List<AppointmentByDate>> getAllAppointments() {
        List<AppointmentByDate> appointments = appointmentByDateService.getAllAppointments();
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }


    //find by doctor id

    @GetMapping("/byDoctorId/{doctorId}")
    public ResponseEntity<List<AppointmentByDate>> findAppointmentsByDoctor(@PathVariable Long doctorId) {
        List<AppointmentByDate> appointments = appointmentByDateService.findByDoctor(doctorId);
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }


    // Get an appointment by date and time
    @GetMapping("/{date}/{time}/{doctor}")
    public ResponseEntity<AppointmentByDate> getAppointmentByDateAndTime(@PathVariable String date, @PathVariable String time,@PathVariable Long doctor) {
        AppointmentByDate appointment = appointmentByDateService.getAppointmentByDateAndTime(date, time,doctor);
        return new ResponseEntity<>(appointment, HttpStatus.OK);
    }

    // Create or update an appointment by date and time
    @PostMapping("/{date}/{time}/{doctorId}")
    public ResponseEntity<AppointmentByDate> createOrUpdateAppointmentByDateAndTime(@PathVariable String date, @PathVariable String time,@PathVariable Long doctorId) {
        AppointmentByDate appointment = appointmentByDateService.createOrUpdateAppointmentByDateAndTime(date, time,doctorId);
        return new ResponseEntity<>(appointment, HttpStatus.CREATED);
    }


}
