package com.QMedic.appointment.Service;

import com.QMedic.appointment.Entity.AppointmentByDate;
import com.QMedic.appointment.Repository.AppointmentByDateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AppointmentByDateService {

    private final AppointmentByDateRepository appointmentByDateRepository;

    @Autowired
    public AppointmentByDateService(AppointmentByDateRepository appointmentByDateRepository) {
        this.appointmentByDateRepository = appointmentByDateRepository;
    }

    // Get all appointments
    public List<AppointmentByDate> getAllAppointments() {
        return appointmentByDateRepository.findAll();
    }

    public List<AppointmentByDate> findByDoctor(Long doctorId){
        return appointmentByDateRepository.findByDoctorId(doctorId);
    }

    // Get an appointment by date and time
    public AppointmentByDate getAppointmentByDateAndTime(String date, String time,Long doctorId) {
        Optional<AppointmentByDate> appointment = appointmentByDateRepository.findByDateAndTimeAndDoctorId(date, time,doctorId);
        return appointment.orElse(null);
    }

    // Create or update an appointment by date and time
    public AppointmentByDate createOrUpdateAppointmentByDateAndTime(String date, String time,Long doctorId) {
        Optional<AppointmentByDate> appointment = appointmentByDateRepository.findByDateAndTimeAndDoctorId(date, time,doctorId);
        if (appointment.isPresent()) {
            // Update the existing appointment
            AppointmentByDate existingAppointment = appointment.get();
            existingAppointment.setCount(existingAppointment.getCount() + 1);
            return appointmentByDateRepository.save(existingAppointment);
        } else {
            // Create a new appointment
            AppointmentByDate newAppointment = new AppointmentByDate();
            newAppointment.setDate(date);
            newAppointment.setTime(time);
            newAppointment.setDoctorId(doctorId);
            newAppointment.setCount(1L);
            return appointmentByDateRepository.save(newAppointment);
        }
    }
}
