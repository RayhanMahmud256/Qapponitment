package com.QMedic.appointment.Service;

import com.QMedic.appointment.Entity.Appointment;
import com.QMedic.appointment.Repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    // Method to save an appointment
    public Appointment saveAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    // Method to get an appointment by id
    public Appointment getAppointmentById(Long id) {
        return appointmentRepository.findById(id).orElse(null);
    }

    // Method to get all appointments
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    // Method to delete an appointment by id
    public void deleteAppointmentById(Long id) {
        appointmentRepository.deleteById(id);
    }

    // Get all appointments for a doctor by a date and time
    public List<Appointment> getAppointmentsByDoctorAndDateAndTime(Long doctorId, String date, String time) {
        return appointmentRepository.findByDoctorIdAndDateAndTime(doctorId, date, time);
    }

}
