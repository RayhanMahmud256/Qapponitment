package com.QMedic.appointment.Controller;

import com.QMedic.appointment.Entity.Appointment;
import com.QMedic.appointment.Service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    // Inject the service dependency
    private final AppointmentService appointmentService;

    @Autowired
    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    // Method to get all appointments
    @GetMapping
    public List<Appointment> getAllAppointments() {
        return appointmentService.getAllAppointments();
    }

    // Method to get an appointment by id
    @GetMapping("/{id}")
    public Appointment getAppointmentById(@PathVariable Long id) {
        return appointmentService.getAppointmentById(id);
    }

    // Method to save an appointment
    @PostMapping
    public Appointment saveAppointment(@RequestBody Appointment appointment) {
        
        return appointmentService.saveAppointment(appointment);
    }

    // Method to delete an appointment by id
    @DeleteMapping("/{id}")
    public void deleteAppointmentById(@PathVariable Long id) {
        appointmentService.deleteAppointmentById(id);
    }

    @GetMapping("getApoByDc&Date&Time/{doctorId}/{date}/{time}")
    public ResponseEntity<List<Appointment>> getAppointmentsByDoctorAndDateAndTime(@PathVariable Long doctorId, @PathVariable String date, @PathVariable String time) {
        List<Appointment> appointments = appointmentService.getAppointmentsByDoctorAndDateAndTime(doctorId, date, time);
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }
}