package com.QMedic.appointment.Controller;

import com.QMedic.appointment.Entity.Doctor;
import com.QMedic.appointment.Service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Controller class for Doctor entity
@RestController
@RequestMapping("/doctors")
public class DoctorController {

    // Inject the service dependency
    private final DoctorService doctorService;

    @Autowired
    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    // Method to get all doctors
    @GetMapping
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }

    // Method to get a doctor by id
    @GetMapping("/{id}")
    public Doctor getDoctorById(@PathVariable Long id) {
        return doctorService.getDoctorById(id);
    }

    // Method to save a doctor
    @PostMapping
    public Doctor saveDoctor(@RequestBody Doctor doctor) {
        return doctorService.saveDoctor(doctor);
    }

    // Method to update a doctor
    @PutMapping("/{id}")
    public Doctor updateDoctor(@PathVariable Long id, @RequestBody Doctor doctor) {
        Doctor existingDoctor = doctorService.getDoctorById(id);
        if (existingDoctor != null) {
            existingDoctor.setNationalId(doctor.getNationalId());
            existingDoctor.setDoctorName(doctor.getDoctorName());
            existingDoctor.setSpeciality(doctor.getSpeciality());
            existingDoctor.setDesignation(doctor.getDesignation());
            existingDoctor.setDescription(doctor.getDescription());
            existingDoctor.setProfileImage(doctor.getProfileImage());
            return doctorService.saveDoctor(existingDoctor);
        } else {
            return null;
        }
    }

    // Method to delete a doctor by id
    @DeleteMapping("/{id}")
    public void deleteDoctorById(@PathVariable Long id) {
        doctorService.deleteDoctorById(id);
    }

}


