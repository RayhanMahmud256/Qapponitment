package com.QMedic.appointment.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.TypeBinderType;

import java.util.List;

@Data
@Entity
@Table
@NoArgsConstructor
@AllArgsConstructor
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long doctorId;
    private String nationalId;
    private String doctorName;
    private String speciality;
    private String designation;
    private String description;
    @Column(name = "profileImage")
    private String profileImage;
    @Embedded
    private Credential credential;
   /*
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(
            name = "doctor_id",
            referencedColumnName = "doctorId"
    )
    private List<Appointment> appointmentList;
   */
}
