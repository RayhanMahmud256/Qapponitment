package com.QMedic.appointment.Repository;

import com.QMedic.appointment.Entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment,Long> {

    // Find all appointments for a doctor by a date and time

   @Query("SELECT a FROM Appointment a WHERE a.doctorId= :doctorId AND a.date = :date AND a.time = :time")
    List<Appointment> findByDoctorIdAndDateAndTime(@Param("doctorId") Long doctorId, @Param("date") String date, @Param("time") String time);


}
