package com.QMedic.appointment.Controller;

import com.QMedic.appointment.Entity.Patient;
import com.QMedic.appointment.Repository.PatientRepository;
import com.QMedic.appointment.Service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/patients")
public class PatientController {

    // Inject the service dependency
    private final PatientService patientService;
    private final PatientRepository patientRepository;

    @Autowired
    public PatientController(PatientService patientService, PatientRepository patientRepository) {
        this.patientService = patientService;
        this.patientRepository = patientRepository;
    }

    // Method to get all patients
    @GetMapping
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    // Method to get a patient by id
    @GetMapping("/{id}")
    public Patient getPatientById(@PathVariable Long id) {
        return patientService.getPatientById(id);
    }

    // Method to save a patient
    @PostMapping("/register")
    public Patient savePatient(@RequestBody Patient patient) {
        return patientService.savePatient(patient);
    }

    // Method to update a patient
    @PutMapping("/{id}")
    public Patient updatePatient(@PathVariable Long id, @RequestBody Patient patient) {
        Patient existingPatient = patientService.getPatientById(id);
        if (existingPatient != null) {
            existingPatient.setName(patient.getName());
            existingPatient.setAge(patient.getAge());
            existingPatient.setBloodGroup(patient.getBloodGroup());
            existingPatient.setLabTest(patient.getLabTest());
            existingPatient.setPrescription(patient.getPrescription());
            existingPatient.setReports(patient.getReports());
            return patientService.savePatient(existingPatient);
        } else {
            return null;
        }
    }



    // Method to delete a patient by id
    @DeleteMapping("/{id}")
    public void deletePatientById(@PathVariable Long id) {
        patientService.deletePatientById(id);
    }



}