package com.QMedic.appointment.Repository;

import com.QMedic.appointment.Entity.Patient;
import org.hibernate.type.descriptor.converter.spi.JpaAttributeConverter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.nio.file.Path;

@Repository
public interface PatientRepository extends JpaRepository<Patient,Long> {

}
