package com.QMedic.appointment.Repository;

import com.QMedic.appointment.Entity.AppointmentByDate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface AppointmentByDateRepository extends JpaRepository<AppointmentByDate,Long> {
    @Query("SELECT a FROM AppointmentByDate a WHERE a.date = :date AND a.time = :time AND a.DoctorId = :doctorId")
    Optional<AppointmentByDate> findByDateAndTimeAndDoctorId(@Param("date") String date, @Param("time") String time, @Param("doctorId") Long doctorId);

    @Query("SELECT a FROM AppointmentByDate a WHERE a.DoctorId = :doctorId")
    List<AppointmentByDate> findByDoctorId(@Param("doctorId") Long doctorId);

}
