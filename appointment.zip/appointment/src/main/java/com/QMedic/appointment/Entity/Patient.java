package com.QMedic.appointment.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Entity
@Table
@NoArgsConstructor
@AllArgsConstructor
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long patientId;
    private String name;
    private Long age;
    private String bloodGroup;
    @Embedded
    private Credential credential;
    @Column(name = "labTestImage")
    private String labTest;
    @Column(name = "prescriptionImage")
    private String prescription;
    @Column(name = "reportsImage")
    private String reports;

}
