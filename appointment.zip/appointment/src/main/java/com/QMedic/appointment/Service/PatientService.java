package com.QMedic.appointment.Service;

import com.QMedic.appointment.Entity.Patient;
import com.QMedic.appointment.Repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {
    @Autowired
    private PatientRepository patientRepository;

    // Method to save a patient
    public Patient savePatient(Patient patient) {
        return patientRepository.save(patient);
    }

    // Method to get a patient by id
    public Patient getPatientById(Long id) {
        return patientRepository.findById(id).orElse(null);
    }

    // Method to get all patients
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    // Method to delete a patient by id
    public void deletePatientById(Long id) {
        patientRepository.deleteById(id);
    }
}
