package com.QMedic.appointment.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Entity
@Table
@NoArgsConstructor
@AllArgsConstructor
public class Compounder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long compounderId;
    private String CompounderName;
    @Embedded
    private Credential credential;
    /*
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(
            name = "compounder_id",
            referencedColumnName = "compounderId"
    )
    private List<Appointment> appointmentList;
     */

}
