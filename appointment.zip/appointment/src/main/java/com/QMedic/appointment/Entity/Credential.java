package com.QMedic.appointment.Entity;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class Credential {
    private String userName;
    private String email;
    private String password;
    private String isAdmin;
    private String isDoctor;
}
